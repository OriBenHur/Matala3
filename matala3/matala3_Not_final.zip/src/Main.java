import java.awt.Color;
import java.util.Random;

public class Main {
	public static Robot[] robots = new Robot[10];
	public static void main(String[] args) {
		RobotRoom room=null;
		room = new RobotRoom();
		Random rand = new Random();

		int  n = rand.nextInt(50) + 1;
		for (int i = 0; i < n; i++) 
		{
			room.setColor(Rand.randome(19,10), Rand.randome(19,10),Color.gray );
		}
		
		
		for (int i = 0; i < 10; i++) 
		{
			robots[i] = new Robot(Rand.randome(19,10), Rand.randome(19,10),Rand.randome(4,4),room);
		}
		
		
		

	}

}
